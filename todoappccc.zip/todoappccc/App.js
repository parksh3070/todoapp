import React, { useState } from 'react';
import { View, StyleSheet, Text, FlatList, TouchableOpacity, TextInput } from 'react-native';
import CalendarPicker from 'react-native-calendar-picker';
import moment from 'moment';

export default function App() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');

  const handleDateSelect = (date) => {
    const formattedDate = moment(date).format('YYYY-MM-DD');
    setSelectedDate(formattedDate);
  };

  const addTodo = () => {
    if (selectedDate && newTodo !== '') {
      const todo = {
        id: Date.now().toString(),
        date: selectedDate,
        task: newTodo,
      };
      setTodos([...todos, todo]);
      setNewTodo('');
    }
  };

  const editTodo = (id, updatedTask) => {
    const updatedTodos = todos.map((todo) => {
      if (todo.id === id) {
        return { ...todo, task: updatedTask };
      }
      return todo;
    });
    setTodos(updatedTodos);
  };

  const deleteTodo = (id) => {
    const updatedTodos = todos.filter((todo) => todo.id !== id);
    setTodos(updatedTodos);
  };

  const renderItem = ({ item }) => (
    <View style={styles.todoItem}>
      <Text style={styles.todoTask}>{item.task}</Text>
      <View style={styles.todoButtons}>
        <TouchableOpacity onPress={() => editTodo(item.id, 'Updated Task')}>
          <Text style={styles.todoButton}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => deleteTodo(item.id)}>
          <Text style={styles.todoButton}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <CalendarPicker onDateChange={handleDateSelect} />
      {selectedDate && (
        <View>
          <Text>Selected Date: {selectedDate}</Text>
          <TextInput
            style={styles.input}
            value={newTodo}
            onChangeText={(text) => setNewTodo(text)}
            placeholder="Enter a new todo"
          />
          <TouchableOpacity onPress={addTodo}>
            <Text>Add Todo</Text>
          </TouchableOpacity>
          <FlatList
            data={todos.filter((todo) => todo.date === selectedDate)}
            keyExtractor={(item) => item.id}
            renderItem={renderItem}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  todoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
  },
  todoTask: {
    flex: 1,
    marginRight: 10,
  },
  todoButtons: {
    flexDirection: 'row',
  },
  todoButton: {
    marginLeft: 5,
    padding: 5,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
});
